# KumaPot
A TCP logging honeypot


A working screenshot of the honeypot
--------
![Screenshot from 2021-08-18 20-16-41](https://user-images.githubusercontent.com/20819968/129988199-0c29f5cf-f3cd-4fd4-8040-ff3dcf966c59.png)
